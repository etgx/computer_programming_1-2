
#ifndef MAIN_PAGE_H // include guard
#define MAIN_PAGE_H

void main_page(ALLEGRO_DISPLAY **, ALLEGRO_SAMPLE **, ALLEGRO_FONT **, const int, const int);

#endif
