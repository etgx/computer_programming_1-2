#ifndef UTIL_H // include guard
#define UTIL_H

void show_err(const int, char *);

#endif
